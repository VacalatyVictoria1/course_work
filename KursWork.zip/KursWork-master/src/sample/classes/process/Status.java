package sample.classes.process;

public enum Status {
    Ready,
    Waiting,
    Running,
    Finished,
    Canceled,
    Rejected
}
