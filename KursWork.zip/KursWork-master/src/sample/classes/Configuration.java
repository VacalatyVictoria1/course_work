package sample.classes;

public class Configuration {
    public static final int coreCount = 2;
    public static int memory = 2048;
    public static int minValue = 10;
    public static int initPCount = 12;
    public static int PRmMultiplier = 2;
    public static int rmOldPIterator = 2;
    public static int maxPriority = 32;
    public static float ZombieDiv = 2f;
    public static int minProcName = 2;
    public static int maxProcName = 7;
    public static int minTickWork =3;
    public static int maxTickWork =20;
    public static int minMemsize =4;
    public static int maxMemsize =300;
    public static int tickIncrement= 1;
}
