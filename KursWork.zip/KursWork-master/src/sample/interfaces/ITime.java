package sample.interfaces;

public interface ITime {
    void timerStep();
}
